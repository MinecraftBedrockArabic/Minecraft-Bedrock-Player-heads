import { world, system, ItemStack,Player} from "@minecraft/server";

//this part of the code rotates the head
//this take time and the head appear in the default rotation for a second
//so i am making the head invisible until the rotation is done
world.afterEvents.playerPlaceBlock.subscribe((event) => {
  const {player,block} = event
  const {y} = player.getRotation()
  const face = block.permutation.getState("minecraft:block_face")
  if(block.permutation.getState("mba:head_rotation") === undefined) return
  if(face == "up"){    
    let rot = y + 360*(y!=Math.abs(y))
    rot = Math.round(rot/22.5)
    rot = rot!=16?rot:0
    block.setPermutation(block.permutation.withState("mba:head_rotation",rot));
  }
  block.setPermutation(block.permutation.withState("mba:show_head",true));
});

system.runInterval(() => {
  world.getPlayers().forEach((player) => {
    const equippable = player.getComponent('equippable')
    const handItem = equippable.getEquipment("Mainhand")
    
    //only useful for creative player
    //when player pick block the head the game give hem the block and not the item from the loot table
    //this clear the head block and give hem the head item
    if(handItem?.typeId.startsWith('mba:head_')){
      const item = new ItemStack(handItem.typeId.replace("mba:","mba:item_"))
      equippable.setEquipment('Mainhand',item)
    }

    //allow the player to get any head with renaming the heads with anvil
    if(handItem?.typeId.startsWith('mba:item_head_')){
      const name = handItem.nameTag
      if(name == undefined) return
      const hexName = convert_hex(name)
      try {
        const item = new ItemStack(`mba:item_head_${hexName}`)
        equippable.setEquipment('Mainhand',item)
      } catch (error) {
        const warned = handItem.getDynamicProperty('warned')
        if(!warned){
          handItem.setDynamicProperty('warned',true)
          equippable.setEquipment('Mainhand',handItem)
          player.sendMessage(`§c${name}\'s head doesn\'t exist in the heads pack`);
        }
      }
    }
  })
},20);


//when player die drop his head if it exist in addon
//also add the killer name to the head
world.afterEvents.entityDie.subscribe((event) => {
  const {damageSource,deadEntity} = event
  const killer = damageSource.damagingEntity
  if(!(deadEntity instanceof Player) || killer == undefined) return
  const name = deadEntity.name
  const hexName = convert_hex(name)
  
  try {
    const killerName = killer.nameTag?killer.nameTag:killer.typeId.split(":")[1]
    const head = new ItemStack(`mba:item_head_${hexName}`)
    head.setLore([`Killed by: ${killerName}`])
    deadEntity.dimension.spawnItem(head, deadEntity.location);
  } catch (error) {
    deadEntity.sendMessage(`§c${name}\'s head doesn\'t exist in the heads pack`);
  }
  
});

function convert_hex(name) {
  let hex_name = "";
  for (let i = 0; i < name.length; i++) {
    hex_name += name.charCodeAt(i).toString(16);
  }
  return hex_name;
}
